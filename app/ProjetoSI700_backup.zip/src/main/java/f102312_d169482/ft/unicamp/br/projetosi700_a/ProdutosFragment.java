package f102312_d169482.ft.unicamp.br.projetosi700_a;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;


/**
 * A simple {@link Fragment} subclass.
 */
public class ProdutosFragment extends Fragment {

    RecyclerView recyclerView;
    ProdutoAdapter produtoAdapter;
    ImageView imageViewFoto;
    TextView txtDescricao;
    TextView txtPreco;
    TextView txtEan;
    View view;

    public ProdutosFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        if (view == null) {
            view = inflater.inflate(R.layout.fragment_produtos, container, false);
        }
        recyclerView =(RecyclerView)view.findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        imageViewFoto = view.findViewById(R.id.imageView);
        txtDescricao = view.findViewById(R.id.txtDescricao);
        txtPreco = view.findViewById(R.id.txtPreco);
        txtEan = view.findViewById(R.id.txtEan);

        produtoAdapter = new ProdutoAdapter(new ArrayList(Arrays.asList(Produtos.produtos)));
        recyclerView.setAdapter(produtoAdapter);

        produtoAdapter.setMyOnItemClickListener(new ProdutoAdapter.MyOnItemClickListener() {
            @Override
            public void myOnItemClick(String nome) {
                Toast.makeText(view.getContext(), nome, Toast.LENGTH_SHORT).show();
            }
        });

        produtoAdapter.setMyOnItemClickListener(new ProdutoAdapter.MyOnItemClickListener() {
            @Override
            public void myOnItemClick(String nome) {
                Toast.makeText(view.getContext(), nome, Toast.LENGTH_SHORT).show();
            }
        });

        produtoAdapter.setMyOnLongItemClickListener(new ProdutoAdapter.MyOnLongItemClickListener() {
            @Override
            public void myOnLongItemClick(int position) {
                Toast.makeText(view.getContext(), String.valueOf(position), Toast.LENGTH_SHORT).show();
                produtoAdapter.notifyDataSetChanged();
            }

        });

        return  view;
    }
}
