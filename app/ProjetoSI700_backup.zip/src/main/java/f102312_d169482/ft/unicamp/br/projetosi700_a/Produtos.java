package f102312_d169482.ft.unicamp.br.projetosi700_a;

public class Produtos {
    public static Produto[] produtos = new Produto[]{
           new Produto("COCA-COLA 2L","7,20",R.drawable.cocacola,"7894900011517"),
            new Produto("CERVEJA SKOL LATA 350ML","2,45",R.drawable.skol,"7891149103102"),
            new Produto("AGUA MINERAL CRYSTAL 500ML","2,00",R.drawable.agua,"7898210052000"),
            new Produto("AGUA DE COCO KERO COCO 330ML","5,60",R.drawable.aguacoco,"7896828000482"),
            new Produto("CHA GELADO ICETEA 340ML LEAO LIMAO","6,30",R.drawable.cha,"7891098000293"),
            new Produto("CAIPIROSKA SMIRNOFF 998ML LIMAO","23,50",R.drawable.caipiroska,"7893218000435"),
            new Produto("REFRIG ANTARCTICA 350ML GUARANA ZERO","2,25",R.drawable.refrigerante,"7891991000727"),
    };
}
