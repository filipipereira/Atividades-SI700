package f102312_d169482.ft.unicamp.br.projetosi700_a;

public class Produto {
    private String descricao;
    private String preco;
    private int foto;
    private String ean;

    public Produto(String descricao, String preco, Integer foto, String ean) {
        this.descricao = descricao;
        this.preco = preco;
        this.foto = foto;
        this.ean = ean;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setNome(String descricao) {
        this.descricao = descricao;
    }

    public String getPreco() {
        return preco;
    }

    public void setPreco(String preco) {
        this.preco = preco;
    }

    public Integer getFoto() {
        return foto;
    }

    public void setFoto(int foto) {
        this.foto = foto;
    }

    public String getEan() {
        return ean;
    }

    public void setEan(String ean) {
        this.ean = ean;
    }
}
