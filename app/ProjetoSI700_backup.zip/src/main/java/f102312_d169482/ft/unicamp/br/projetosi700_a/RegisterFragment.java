package f102312_d169482.ft.unicamp.br.projetosi700_a;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;


public class RegisterFragment extends Fragment {

    View view;
    Spinner spinner;
    String[] paths = {"18 a 24", "25 a 42", "43 ou mais"};


    public RegisterFragment() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (view == null) {
            view = inflater.inflate(R.layout.fragment_register, container, false);
        }

        spinner = (Spinner)view.findViewById(R.id.spn_idade);
        ArrayAdapter<String> adapter;
        adapter = new ArrayAdapter<String>(view.getContext(),
                android.R.layout.simple_spinner_item  ,paths);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        //spinner.setOnItemSelectedListener(this);
        return  view;
    }

}
