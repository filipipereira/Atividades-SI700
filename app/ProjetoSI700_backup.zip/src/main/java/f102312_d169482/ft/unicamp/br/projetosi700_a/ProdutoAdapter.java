package f102312_d169482.ft.unicamp.br.projetosi700_a;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ProdutoAdapter extends RecyclerView.Adapter {

    private ArrayList<Produto> produtos;
    private MyOnItemClickListener myOnItemClickListener;
    private MyOnLongItemClickListener myOnLongItemClickListener;

    ProdutoAdapter(ArrayList<Produto> produtos) {
        this.produtos = produtos;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_layout, parent, false);
        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (myOnItemClickListener != null) {
                    TextView txt = view.findViewById(R.id.txtDescricao);
                    myOnItemClickListener.myOnItemClick(txt.getText().toString());
                }
            }
        });
        return new ProdutoViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        ((ProdutoViewHolder)holder).bind(produtos.get(position));
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                if (myOnLongItemClickListener != null) {
                    myOnLongItemClickListener.myOnLongItemClick(position);
                    produtos.remove(position);
                    return true;
                }
                return false;
            }
        });
    }

    @Override
    public int getItemCount() {
        return produtos.size();
    }

    void setMyOnItemClickListener(MyOnItemClickListener myOnItemClickListener) {
        this.myOnItemClickListener = myOnItemClickListener;
    }

    void setMyOnLongItemClickListener(MyOnLongItemClickListener myOnLongItemClickListener) {
        this.myOnLongItemClickListener = myOnLongItemClickListener;
    }

    public class ProdutoViewHolder extends RecyclerView.ViewHolder{

        ImageView imageView;
        TextView txtViewDescricao;
        TextView txtViewPreco;
        TextView txtViewEan;

        ProdutoViewHolder(View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
            txtViewDescricao = itemView.findViewById(R.id.txtDescricao);
            txtViewPreco = itemView.findViewById(R.id.txtPreco);
            txtViewEan = itemView.findViewById(R.id.txtEan);
        }

        void bind(Produto prod) {
            imageView.setImageResource(prod.getFoto());
            txtViewDescricao.setText(prod.getDescricao());
            txtViewPreco.setText((prod.getPreco()));
            txtViewEan.setText(prod.getEan());
        }
    }

    public interface MyOnItemClickListener {
        void myOnItemClick(String descricao);
    }

    public interface MyOnLongItemClickListener {
        void myOnLongItemClick(int position);
    }
}
